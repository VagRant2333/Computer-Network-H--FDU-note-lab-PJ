#include <stdio.h>

/* 
 * node2.c
 * Implementation of distributed distance vector routing for Node 2
 */

struct rtpkt {
  int sourceid;       /* id of sending router sending this pkt */
  int destid;         /* id of router to which pkt being sent 
                         (must be an immediate neighbor) */
  int mincost[4];    /* min cost to node 0 ... 3 */
};

extern int TRACE;
extern int YES;
extern int NO;
extern float clocktime;

#define NODE_ID 2
#define INFINITY 9999
#define NODE_COUNT 4

/* Distance table for Node 2 */
struct distance_table {
  int costs[NODE_COUNT][NODE_COUNT];
} dist_table_2;

/* Direct link costs to neighbors */
int link_costs_2[NODE_COUNT] = {3, 1, 0, 2};

/* Next hop for each destination */
int next_hop_2[NODE_COUNT] = {0, 1, 2, 3};

/* Current minimum costs to each node */
int min_costs_2[NODE_COUNT] = {INFINITY, INFINITY, INFINITY, INFINITY};

/* Function prototypes */
void rtinit2();
void rtupdate2(struct rtpkt *rcvdpkt);
void printdt2(struct distance_table *dtptr);
void tolayer2(struct rtpkt packet);
void linkhandler2(int linkid, int newcost);

/* 
 * rtinit2()
 * Initializes the distance table and sends initial costs to neighbors.
 */
void rtinit2() {
    int i, j;
    struct rtpkt packet;

    printf("rtinit2 called at t=%.3f\n", clocktime);

    // Initialize distance table with infinity
    for (i = 0; i < NODE_COUNT; i++) {
        for (j = 0; j < NODE_COUNT; j++) {
            dist_table_2.costs[i][j] = INFINITY;
        }
    }

    // Set costs to neighbors and self
    packet.sourceid = NODE_ID;
    
    for (i = 0; i < NODE_COUNT; i++) {
        min_costs_2[i] = link_costs_2[i];
        dist_table_2.costs[i][NODE_ID] = link_costs_2[i];
        packet.mincost[i] = link_costs_2[i];
    }

    // Print initial table
    printdt2(&dist_table_2);

    // Send updates to neighbors
    for (i = 0; i < NODE_COUNT; i++) {
        if (i == NODE_ID || link_costs_2[i] == INFINITY) {
            continue;
        }

        packet.destid = i;
        printf("rtinit2: sending packet to node %d\n", i);
        tolayer2(packet);
    }
}

/* 
 * rtupdate2()
 * Called when a packet is received from a neighbor.
 */
void rtupdate2(struct rtpkt *rcvdpkt) {
    int i, j, k;
    int sender_id = rcvdpkt->sourceid;
    int is_changed = 0;
    int current_min_costs[NODE_COUNT];
    struct rtpkt packet;

    printf("rtupdate2 called at t=%.3f, received from %d\n", clocktime, sender_id);

    // Update distance table
    for (i = 0; i < NODE_COUNT; i++) {
        dist_table_2.costs[i][sender_id] = rcvdpkt->mincost[i] + dist_table_2.costs[sender_id][NODE_ID];
    }

    // Recompute min costs
    for(k=0; k<NODE_COUNT; k++) current_min_costs[k] = INFINITY;
    current_min_costs[NODE_ID] = 0;

    for (i = 0; i < NODE_COUNT; i++) {
        if (i == NODE_ID) continue;

        for (j = 0; j < NODE_COUNT; j++) {
            int cost_via_j = dist_table_2.costs[i][j];
            if (current_min_costs[i] > cost_via_j) {
                current_min_costs[i] = cost_via_j;
                next_hop_2[i] = j;
            }
        }
    }

    // Check for changes
    for (i = 0; i < NODE_COUNT; i++) {
        if (i == NODE_ID) continue;
        
        if (current_min_costs[i] != min_costs_2[i]) {
            is_changed = 1;
            min_costs_2[i] = current_min_costs[i];
        }
    }

    printdt2(&dist_table_2);

    if (is_changed) {
        printf("rtupdate2: costs changed, notifying neighbors\n");
        packet.sourceid = NODE_ID;
        
        for (i = 0; i < NODE_COUNT; i++) {
            if (i == NODE_ID || link_costs_2[i] == INFINITY) continue;

            packet.destid = i;
            for (j = 0; j < NODE_COUNT; j++) {
                packet.mincost[j] = min_costs_2[j];
            }
            
            printf("rtupdate2: sending update to %d\n", i);
            tolayer2(packet);
        }
    } else {
        printf("rtupdate2: no change in min costs\n");
    }
}

/*
 * printdt2()
 * Prints the contents of the distance table.
 */
void printdt2(struct distance_table *dtptr) {
    printf("                via     \n");
    printf("   D2 |    0     1    3 \n");
    printf("  ----|-----------------\n");
    printf("     0|  %3d   %3d   %3d\n", dtptr->costs[0][0], dtptr->costs[0][1], dtptr->costs[0][3]);
    printf("dest 1|  %3d   %3d   %3d\n", dtptr->costs[1][0], dtptr->costs[1][1], dtptr->costs[1][3]);
    printf("     3|  %3d   %3d   %3d\n", dtptr->costs[3][0], dtptr->costs[3][1], dtptr->costs[3][3]);
}

/*
 * linkhandler2()
 * Called when the cost of a link changes.
 */
void linkhandler2(int linkid, int newcost) {
    int i, j, k;
    int old_cost;
    int is_changed = 0;
    int current_min_costs[NODE_COUNT];
    struct rtpkt packet;

    printf("linkhandler2 called at t=%.3f: link %d cost changed to %d\n", clocktime, linkid, newcost);
    
    old_cost = link_costs_2[linkid];
    link_costs_2[linkid] = newcost;
    dist_table_2.costs[linkid][NODE_ID] = newcost; 

    for (i = 0; i < NODE_COUNT; i++) {
        if (dist_table_2.costs[i][linkid] != INFINITY) {
            dist_table_2.costs[i][linkid] = dist_table_2.costs[i][linkid] - old_cost + newcost;
        }
    }

    for(k=0; k<NODE_COUNT; k++) current_min_costs[k] = INFINITY;
    current_min_costs[NODE_ID] = 0;

    for (i = 0; i < NODE_COUNT; i++) {
        if (i == NODE_ID) continue;

        for (j = 0; j < NODE_COUNT; j++) {
            int cost_via_j = dist_table_2.costs[i][j];
            if (current_min_costs[i] > cost_via_j) {
                current_min_costs[i] = cost_via_j;
                next_hop_2[i] = j;
            }
        }
    }

    for (i = 0; i < NODE_COUNT; i++) {
        if (i == NODE_ID) continue;
        
        if (current_min_costs[i] != min_costs_2[i]) {
            is_changed = 1;
            min_costs_2[i] = current_min_costs[i];
        }
    }

    printdt2(&dist_table_2);

    if (is_changed) {
        printf("linkhandler2: costs changed, notifying neighbors\n");
        packet.sourceid = NODE_ID;
        
        for (i = 0; i < NODE_COUNT; i++) {
            if (i == NODE_ID || link_costs_2[i] == INFINITY) continue;

            packet.destid = i;
            for (j = 0; j < NODE_COUNT; j++) {
                packet.mincost[j] = min_costs_2[j];
            }
            
            printf("linkhandler2: sending update to %d\n", i);
            tolayer2(packet);
        }
    } else {
        printf("linkhandler2: no change in min costs\n");
    }
}
