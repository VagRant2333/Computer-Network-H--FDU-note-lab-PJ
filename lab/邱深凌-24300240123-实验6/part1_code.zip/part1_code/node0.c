#include <stdio.h>

/* 
 * node0.c
 * Implementation of distributed distance vector routing for Node 0
 */

struct rtpkt {
  int sourceid;       /* id of sending router sending this pkt */
  int destid;         /* id of router to which pkt being sent 
                         (must be an immediate neighbor) */
  int mincost[4];    /* min cost to node 0 ... 3 */
};

extern int TRACE;
extern int YES;
extern int NO;
extern float clocktime; /* defined in prog3.c */

#define NODE_ID 0
#define INFINITY 9999
#define NODE_COUNT 4

/* Distance table for Node 0 */
struct distance_table {
  int costs[NODE_COUNT][NODE_COUNT];
} dist_table_0;

/* Direct link costs to neighbors */
int link_costs_0[NODE_COUNT] = {0, 1, 3, 7};

/* Next hop for each destination */
int next_hop_0[NODE_COUNT] = {0, 1, 2, 3};

/* Current minimum costs to each node */
int min_costs_0[NODE_COUNT] = {INFINITY, INFINITY, INFINITY, INFINITY};

/* Function prototypes */
void rtinit0();
void rtupdate0(struct rtpkt *rcvdpkt);
void printdt0(struct distance_table *dtptr);
void tolayer2(struct rtpkt packet);
void linkhandler0(int linkid, int newcost);

/* 
 * rtinit0()
 * Initializes the distance table and sends initial costs to neighbors.
 */
void rtinit0() {
    int i, j;
    struct rtpkt packet;

    printf("rtinit0 called at t=%.3f\n", clocktime);

    // Initialize distance table with infinity
    for (i = 0; i < NODE_COUNT; i++) {
        for (j = 0; j < NODE_COUNT; j++) {
            dist_table_0.costs[i][j] = INFINITY;
        }
    }

    // Set costs to neighbors and self
    packet.sourceid = NODE_ID;
    
    for (i = 0; i < NODE_COUNT; i++) {
        // Initial min costs are just link costs
        min_costs_0[i] = link_costs_0[i];
        // Update distance table for self (column 0)
        dist_table_0.costs[i][NODE_ID] = link_costs_0[i];
        // Prepare packet mincosts
        packet.mincost[i] = link_costs_0[i];
    }

    // Print initial table
    printdt0(&dist_table_0);

    // Send updates to neighbors
    for (i = 0; i < NODE_COUNT; i++) {
        // Skip self and non-neighbors
        if (i == NODE_ID || link_costs_0[i] == INFINITY) {
            continue;
        }

        packet.destid = i;
        printf("rtinit0: sending packet to node %d\n", i);
        tolayer2(packet);
    }
}

/* 
 * rtupdate0()
 * Called when a packet is received from a neighbor.
 * Updates distance table and sends new min costs if changed.
 */
void rtupdate0(struct rtpkt *rcvdpkt) {
    int i, j, k;
    int sender_id = rcvdpkt->sourceid;
    int is_changed = 0;
    int current_min_costs[NODE_COUNT];
    struct rtpkt packet;

    printf("rtupdate0 called at t=%.3f, received from %d\n", clocktime, sender_id);

    // Update distance table with received costs
    // D_x(y) = min_v { c(x,v) + D_v(y) }
    // Here we update the column for the sender
    for (i = 0; i < NODE_COUNT; i++) {
        // We don't add link cost here because the table stores D_v(y) in column v?
        // Wait, the original code was: dt0.costs[i][sourceid] = rcvdpkt->mincost[i] + dt0.costs[sourceid][THISNODE];
        // dt0.costs[sourceid][THISNODE] is c(x,v).
        // So it stores the total cost through v?
        // Let's check the struct definition in original code:
        // "cost[i][j] 为节点 0 通过邻居 j 到达节点 i 的当前开销估计值"
        // So yes, it is c(0,j) + D_j(i).
        
        // rcvdpkt->mincost[i] is D_v(i) (cost from neighbor v to node i)
        // dist_table_0.costs[sender_id][NODE_ID] is c(0, sender_id) (cost from 0 to neighbor v)
        // Wait, dist_table_0.costs[sender_id][NODE_ID] was initialized to link_costs_0[sender_id].
        // So yes, this is correct.
        
        dist_table_0.costs[i][sender_id] = rcvdpkt->mincost[i] + dist_table_0.costs[sender_id][NODE_ID];
    }

    // Recompute min costs to all nodes
    
    // Initialize with infinity
    for(k=0; k<NODE_COUNT; k++) current_min_costs[k] = INFINITY;
    current_min_costs[NODE_ID] = 0; // Cost to self is 0

    for (i = 0; i < NODE_COUNT; i++) {
        if (i == NODE_ID) continue;

        // Find min cost to node i via all neighbors
        for (j = 0; j < NODE_COUNT; j++) {
            int cost_via_j = dist_table_0.costs[i][j];
            if (current_min_costs[i] > cost_via_j) {
                current_min_costs[i] = cost_via_j;
                next_hop_0[i] = j;
            }
        }
    }

    // Check if min costs changed
    for (i = 0; i < NODE_COUNT; i++) {
        if (i == NODE_ID) continue;
        
        if (current_min_costs[i] != min_costs_0[i]) {
            is_changed = 1;
            min_costs_0[i] = current_min_costs[i];
        }
    }

    printdt0(&dist_table_0);

    if (is_changed) {
        printf("rtupdate0: costs changed, notifying neighbors\n");
        packet.sourceid = NODE_ID;
        
        for (i = 0; i < NODE_COUNT; i++) {
            if (i == NODE_ID || link_costs_0[i] == INFINITY) continue;

            packet.destid = i;
            // Prepare min costs to send
            for (j = 0; j < NODE_COUNT; j++) {
                packet.mincost[j] = min_costs_0[j];
            }
            
            printf("rtupdate0: sending update to %d\n", i);
            tolayer2(packet);
        }
    } else {
        printf("rtupdate0: no change in min costs\n");
    }
}

/*
 * printdt0()
 * Prints the contents of the distance table.
 */
void printdt0(struct distance_table *dtptr) {
    printf("                via     \n");
    printf("   D0 |    1     2    3 \n");
    printf("  ----|-----------------\n");
    printf("     1|  %3d   %3d   %3d\n", dtptr->costs[1][1], dtptr->costs[1][2], dtptr->costs[1][3]);
    printf("dest 2|  %3d   %3d   %3d\n", dtptr->costs[2][1], dtptr->costs[2][2], dtptr->costs[2][3]);
    printf("     3|  %3d   %3d   %3d\n", dtptr->costs[3][1], dtptr->costs[3][2], dtptr->costs[3][3]);
}

/*
 * linkhandler0()
 * Called when the cost of a link changes.
 */
void linkhandler0(int linkid, int newcost) {
    int i, j, k;
    int old_cost;
    int is_changed = 0;
    int current_min_costs[NODE_COUNT];
    struct rtpkt packet;

    printf("linkhandler0 called at t=%.3f: link %d cost changed to %d\n", clocktime, linkid, newcost);
    
    old_cost = link_costs_0[linkid];
    link_costs_0[linkid] = newcost;
    dist_table_0.costs[linkid][NODE_ID] = newcost; 

    for (i = 0; i < NODE_COUNT; i++) {
        if (dist_table_0.costs[i][linkid] != INFINITY) {
            dist_table_0.costs[i][linkid] = dist_table_0.costs[i][linkid] - old_cost + newcost;
        }
    }

    for(k=0; k<NODE_COUNT; k++) current_min_costs[k] = INFINITY;
    current_min_costs[NODE_ID] = 0;

    for (i = 0; i < NODE_COUNT; i++) {
        if (i == NODE_ID) continue;

        for (j = 0; j < NODE_COUNT; j++) {
            int cost_via_j = dist_table_0.costs[i][j];
            if (current_min_costs[i] > cost_via_j) {
                current_min_costs[i] = cost_via_j;
                next_hop_0[i] = j;
            }
        }
    }

    for (i = 0; i < NODE_COUNT; i++) {
        if (i == NODE_ID) continue;
        
        if (current_min_costs[i] != min_costs_0[i]) {
            is_changed = 1;
            min_costs_0[i] = current_min_costs[i];
        }
    }

    printdt0(&dist_table_0);

    if (is_changed) {
        printf("linkhandler0: costs changed, notifying neighbors\n");
        packet.sourceid = NODE_ID;
        
        for (i = 0; i < NODE_COUNT; i++) {
            if (i == NODE_ID || link_costs_0[i] == INFINITY) continue;

            packet.destid = i;
            for (j = 0; j < NODE_COUNT; j++) {
                packet.mincost[j] = min_costs_0[j];
            }
            
            printf("linkhandler0: sending update to %d\n", i);
            tolayer2(packet);
        }
    } else {
        printf("linkhandler0: no change in min costs\n");
    }
}
