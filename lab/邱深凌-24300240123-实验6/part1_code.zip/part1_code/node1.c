#include <stdio.h>

/* 
 * node1.c
 * Implementation of distributed distance vector routing for Node 1
 */

struct rtpkt {
  int sourceid;       /* id of sending router sending this pkt */
  int destid;         /* id of router to which pkt being sent 
                         (must be an immediate neighbor) */
  int mincost[4];    /* min cost to node 0 ... 3 */
};

extern int TRACE;
extern int YES;
extern int NO;
extern float clocktime;

#define NODE_ID 1
#define INFINITY 9999
#define NODE_COUNT 4

/* Distance table for Node 1 */
struct distance_table {
  int costs[NODE_COUNT][NODE_COUNT];
} dist_table_1;

/* Direct link costs to neighbors */
int link_costs_1[NODE_COUNT] = {1, 0, 1, INFINITY};

/* Next hop for each destination */
int next_hop_1[NODE_COUNT] = {0, 1, 2, 3};

/* Current minimum costs to each node */
int min_costs_1[NODE_COUNT] = {INFINITY, INFINITY, INFINITY, INFINITY};

/* Function prototypes */
void rtinit1();
void rtupdate1(struct rtpkt *rcvdpkt);
void printdt1(struct distance_table *dtptr);
void tolayer2(struct rtpkt packet);
void linkhandler1(int linkid, int newcost);

/* 
 * rtinit1()
 * Initializes the distance table and sends initial costs to neighbors.
 */
void rtinit1() {
    int i, j;
    struct rtpkt packet;

    printf("rtinit1 called at t=%.3f\n", clocktime);

    // Initialize distance table with infinity
    for (i = 0; i < NODE_COUNT; i++) {
        for (j = 0; j < NODE_COUNT; j++) {
            dist_table_1.costs[i][j] = INFINITY;
        }
    }

    // Set costs to neighbors and self
    packet.sourceid = NODE_ID;
    
    for (i = 0; i < NODE_COUNT; i++) {
        min_costs_1[i] = link_costs_1[i];
        dist_table_1.costs[i][NODE_ID] = link_costs_1[i];
        packet.mincost[i] = link_costs_1[i];
    }

    // Print initial table
    printdt1(&dist_table_1);

    // Send updates to neighbors
    for (i = 0; i < NODE_COUNT; i++) {
        if (i == NODE_ID || link_costs_1[i] == INFINITY) {
            continue;
        }

        packet.destid = i;
        printf("rtinit1: sending packet to node %d\n", i);
        tolayer2(packet);
    }
}

/* 
 * rtupdate1()
 * Called when a packet is received from a neighbor.
 */
void rtupdate1(struct rtpkt *rcvdpkt) {
    int i, j, k;
    int sender_id = rcvdpkt->sourceid;
    int is_changed = 0;
    int current_min_costs[NODE_COUNT];
    struct rtpkt packet;

    printf("rtupdate1 called at t=%.3f, received from %d\n", clocktime, sender_id);

    // Update distance table
    for (i = 0; i < NODE_COUNT; i++) {
        dist_table_1.costs[i][sender_id] = rcvdpkt->mincost[i] + dist_table_1.costs[sender_id][NODE_ID];
    }

    // Recompute min costs
    for(k=0; k<NODE_COUNT; k++) current_min_costs[k] = INFINITY;
    current_min_costs[NODE_ID] = 0;

    for (i = 0; i < NODE_COUNT; i++) {
        if (i == NODE_ID) continue;

        for (j = 0; j < NODE_COUNT; j++) {
            int cost_via_j = dist_table_1.costs[i][j];
            if (current_min_costs[i] > cost_via_j) {
                current_min_costs[i] = cost_via_j;
                next_hop_1[i] = j;
            }
        }
    }

    // Check for changes
    for (i = 0; i < NODE_COUNT; i++) {
        if (i == NODE_ID) continue;
        
        if (current_min_costs[i] != min_costs_1[i]) {
            is_changed = 1;
            min_costs_1[i] = current_min_costs[i];
        }
    }

    printdt1(&dist_table_1);

    if (is_changed) {
        printf("rtupdate1: costs changed, notifying neighbors\n");
        packet.sourceid = NODE_ID;
        
        for (i = 0; i < NODE_COUNT; i++) {
            if (i == NODE_ID || link_costs_1[i] == INFINITY) continue;

            packet.destid = i;
            for (j = 0; j < NODE_COUNT; j++) {
                packet.mincost[j] = min_costs_1[j];
            }
            
            printf("rtupdate1: sending update to %d\n", i);
            tolayer2(packet);
        }
    } else {
        printf("rtupdate1: no change in min costs\n");
    }
}

/*
 * printdt1()
 * Prints the contents of the distance table.
 */
void printdt1(struct distance_table *dtptr) {
    printf("             via   \n");
    printf("   D1 |    0     2 \n");
    printf("  ----|-----------\n");
    printf("     0|  %3d   %3d\n", dtptr->costs[0][0], dtptr->costs[0][2]);
    printf("dest 2|  %3d   %3d\n", dtptr->costs[2][0], dtptr->costs[2][2]);
    printf("     3|  %3d   %3d\n", dtptr->costs[3][0], dtptr->costs[3][2]);
}

/*
 * linkhandler1()
 * Called when the cost of a link changes.
 */
void linkhandler1(int linkid, int newcost) {
    int i, j, k;
    int old_cost;
    int is_changed = 0;
    int current_min_costs[NODE_COUNT];
    struct rtpkt packet;

    printf("linkhandler1 called at t=%.3f: link %d cost changed to %d\n", clocktime, linkid, newcost);
    
    old_cost = link_costs_1[linkid];
    link_costs_1[linkid] = newcost;
    dist_table_1.costs[linkid][NODE_ID] = newcost; 

    for (i = 0; i < NODE_COUNT; i++) {
        if (dist_table_1.costs[i][linkid] != INFINITY) {
            dist_table_1.costs[i][linkid] = dist_table_1.costs[i][linkid] - old_cost + newcost;
        }
    }

    for(k=0; k<NODE_COUNT; k++) current_min_costs[k] = INFINITY;
    current_min_costs[NODE_ID] = 0;

    for (i = 0; i < NODE_COUNT; i++) {
        if (i == NODE_ID) continue;

        for (j = 0; j < NODE_COUNT; j++) {
            int cost_via_j = dist_table_1.costs[i][j];
            if (current_min_costs[i] > cost_via_j) {
                current_min_costs[i] = cost_via_j;
                next_hop_1[i] = j;
            }
        }
    }

    for (i = 0; i < NODE_COUNT; i++) {
        if (i == NODE_ID) continue;
        
        if (current_min_costs[i] != min_costs_1[i]) {
            is_changed = 1;
            min_costs_1[i] = current_min_costs[i];
        }
    }

    printdt1(&dist_table_1);

    if (is_changed) {
        printf("linkhandler1: costs changed, notifying neighbors\n");
        packet.sourceid = NODE_ID;
        
        for (i = 0; i < NODE_COUNT; i++) {
            if (i == NODE_ID || link_costs_1[i] == INFINITY) continue;

            packet.destid = i;
            for (j = 0; j < NODE_COUNT; j++) {
                packet.mincost[j] = min_costs_1[j];
            }
            
            printf("linkhandler1: sending update to %d\n", i);
            tolayer2(packet);
        }
    } else {
        printf("linkhandler1: no change in min costs\n");
    }
}
