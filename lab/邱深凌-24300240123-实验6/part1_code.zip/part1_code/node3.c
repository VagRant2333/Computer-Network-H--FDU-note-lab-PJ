#include <stdio.h>

/* 
 * node3.c
 * Implementation of distributed distance vector routing for Node 3
 */

struct rtpkt {
  int sourceid;       /* id of sending router sending this pkt */
  int destid;         /* id of router to which pkt being sent 
                         (must be an immediate neighbor) */
  int mincost[4];    /* min cost to node 0 ... 3 */
};

extern int TRACE;
extern int YES;
extern int NO;
extern float clocktime;

#define NODE_ID 3
#define INFINITY 9999
#define NODE_COUNT 4

/* Distance table for Node 3 */
struct distance_table {
  int costs[NODE_COUNT][NODE_COUNT];
} dist_table_3;

/* Direct link costs to neighbors */
int link_costs_3[NODE_COUNT] = {7, INFINITY, 2, 0};

/* Next hop for each destination */
int next_hop_3[NODE_COUNT] = {0, 1, 2, 3};

/* Current minimum costs to each node */
int min_costs_3[NODE_COUNT] = {INFINITY, INFINITY, INFINITY, INFINITY};

/* Function prototypes */
void rtinit3();
void rtupdate3(struct rtpkt *rcvdpkt);
void printdt3(struct distance_table *dtptr);
void tolayer2(struct rtpkt packet);
void linkhandler3(int linkid, int newcost);

/* 
 * rtinit3()
 * Initializes the distance table and sends initial costs to neighbors.
 */
void rtinit3() {
    int i, j;
    struct rtpkt packet;

    printf("rtinit3 called at t=%.3f\n", clocktime);

    // Initialize distance table with infinity
    for (i = 0; i < NODE_COUNT; i++) {
        for (j = 0; j < NODE_COUNT; j++) {
            dist_table_3.costs[i][j] = INFINITY;
        }
    }

    // Set costs to neighbors and self
    packet.sourceid = NODE_ID;
    
    for (i = 0; i < NODE_COUNT; i++) {
        min_costs_3[i] = link_costs_3[i];
        dist_table_3.costs[i][NODE_ID] = link_costs_3[i];
        packet.mincost[i] = link_costs_3[i];
    }

    // Print initial table
    printdt3(&dist_table_3);

    // Send updates to neighbors
    for (i = 0; i < NODE_COUNT; i++) {
        if (i == NODE_ID || link_costs_3[i] == INFINITY) {
            continue;
        }

        packet.destid = i;
        printf("rtinit3: sending packet to node %d\n", i);
        tolayer2(packet);
    }
}

/* 
 * rtupdate3()
 * Called when a packet is received from a neighbor.
 */
void rtupdate3(struct rtpkt *rcvdpkt) {
    int i, j, k;
    int sender_id = rcvdpkt->sourceid;
    int is_changed = 0;
    int current_min_costs[NODE_COUNT];
    struct rtpkt packet;

    printf("rtupdate3 called at t=%.3f, received from %d\n", clocktime, sender_id);

    // Update distance table
    for (i = 0; i < NODE_COUNT; i++) {
        dist_table_3.costs[i][sender_id] = rcvdpkt->mincost[i] + dist_table_3.costs[sender_id][NODE_ID];
    }

    // Recompute min costs
    for(k=0; k<NODE_COUNT; k++) current_min_costs[k] = INFINITY;
    current_min_costs[NODE_ID] = 0;

    for (i = 0; i < NODE_COUNT; i++) {
        if (i == NODE_ID) continue;

        for (j = 0; j < NODE_COUNT; j++) {
            int cost_via_j = dist_table_3.costs[i][j];
            if (current_min_costs[i] > cost_via_j) {
                current_min_costs[i] = cost_via_j;
                next_hop_3[i] = j;
            }
        }
    }

    // Check for changes
    for (i = 0; i < NODE_COUNT; i++) {
        if (i == NODE_ID) continue;
        
        if (current_min_costs[i] != min_costs_3[i]) {
            is_changed = 1;
            min_costs_3[i] = current_min_costs[i];
        }
    }

    printdt3(&dist_table_3);

    if (is_changed) {
        printf("rtupdate3: costs changed, notifying neighbors\n");
        packet.sourceid = NODE_ID;
        
        for (i = 0; i < NODE_COUNT; i++) {
            if (i == NODE_ID || link_costs_3[i] == INFINITY) continue;

            packet.destid = i;
            for (j = 0; j < NODE_COUNT; j++) {
                packet.mincost[j] = min_costs_3[j];
            }
            
            printf("rtupdate3: sending update to %d\n", i);
            tolayer2(packet);
        }
    } else {
        printf("rtupdate3: no change in min costs\n");
    }
}

/*
 * printdt3()
 * Prints the contents of the distance table.
 */
void printdt3(struct distance_table *dtptr) {
    printf("             via     \n");
    printf("   D3 |    0     2 \n");
    printf("  ----|-----------\n");
    printf("     0|  %3d   %3d\n", dtptr->costs[0][0], dtptr->costs[0][2]);
    printf("dest 1|  %3d   %3d\n", dtptr->costs[1][0], dtptr->costs[1][2]);
    printf("     2|  %3d   %3d\n", dtptr->costs[2][0], dtptr->costs[2][2]);
}

/*
 * linkhandler3()
 * Called when the cost of a link changes.
 */
void linkhandler3(int linkid, int newcost) {
    int i, j, k;
    int old_cost;
    int is_changed = 0;
    int current_min_costs[NODE_COUNT];
    struct rtpkt packet;

    printf("linkhandler3 called at t=%.3f: link %d cost changed to %d\n", clocktime, linkid, newcost);
    
    old_cost = link_costs_3[linkid];
    link_costs_3[linkid] = newcost;
    dist_table_3.costs[linkid][NODE_ID] = newcost; 

    for (i = 0; i < NODE_COUNT; i++) {
        if (dist_table_3.costs[i][linkid] != INFINITY) {
            dist_table_3.costs[i][linkid] = dist_table_3.costs[i][linkid] - old_cost + newcost;
        }
    }

    for(k=0; k<NODE_COUNT; k++) current_min_costs[k] = INFINITY;
    current_min_costs[NODE_ID] = 0;

    for (i = 0; i < NODE_COUNT; i++) {
        if (i == NODE_ID) continue;

        for (j = 0; j < NODE_COUNT; j++) {
            int cost_via_j = dist_table_3.costs[i][j];
            if (current_min_costs[i] > cost_via_j) {
                current_min_costs[i] = cost_via_j;
                next_hop_3[i] = j;
            }
        }
    }

    for (i = 0; i < NODE_COUNT; i++) {
        if (i == NODE_ID) continue;
        
        if (current_min_costs[i] != min_costs_3[i]) {
            is_changed = 1;
            min_costs_3[i] = current_min_costs[i];
        }
    }

    printdt3(&dist_table_3);

    if (is_changed) {
        printf("linkhandler3: costs changed, notifying neighbors\n");
        packet.sourceid = NODE_ID;
        
        for (i = 0; i < NODE_COUNT; i++) {
            if (i == NODE_ID || link_costs_3[i] == INFINITY) continue;

            packet.destid = i;
            for (j = 0; j < NODE_COUNT; j++) {
                packet.mincost[j] = min_costs_3[j];
            }
            
            printf("linkhandler3: sending update to %d\n", i);
            tolayer2(packet);
        }
    } else {
        printf("linkhandler3: no change in min costs\n");
    }
}
